function [subpop, subfit]= neigh_point(DB, seedx,  seedfit, K) 
% [subpop, subfit]= neigh_point(DB, seedx,  seedfit, K) 
% Calculate neighbor points containing seed point
% Date: 2/12/2023
% Written by Huixiang Zhen, zhenhuixiang@cug.edu.cn

B = setxor(DB, [seedx  seedfit], 'rows'); % Remove the seed points in A
[~, ind]= sort(pdist2(B(:, 1:end-1),  seedx), 'ascend'); % Calculate the distance from all points to the seed point
subpop = B(ind(1:K), 1 : end - 1);
subfit = B(ind(1:K), end);   
subpop = [subpop; seedx];
subfit =[subfit; seedfit]; % 
