function [subpop, subfit]= neigh_point_B(DB, seedx, K) 
% [subpop, subfit] = neigh_point_B(DB, seedx, K)
% Calculate neighbor points of seedx not containing seed point
% Date: 2/12/2023
% Written by Huixiang Zhen, zhenhuixiang@cug.edu.cn

[~, ind]= sort(pdist2(DB(:,1:end-1),  seedx), 'ascend'); % Calculate the distance from all points to the seed point
subpop = DB(ind(1:K), 1 : end-1);
subfit = DB(ind(1:K), end);
