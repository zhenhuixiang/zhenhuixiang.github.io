function [hx,hf,NFE,Max_NFE,Archive_FEs,Archive_convergence] = ESPSO(FUN,Dim,L_bound,U_bound)

% 0. Initialization parameters
Max_NFE = 1000;
NFE = 0;
initial_sample_size = 80;
Particle_Number = 80;
if Dim >= 100
    initial_sample_size = 120;
    Particle_Number = 120;
end
generation = 1;
show=1;

% 0. Initialize the data set
sam = repmat(L_bound,initial_sample_size,1)+(repmat(U_bound,initial_sample_size,1)-repmat(L_bound,initial_sample_size,1)).*lhsdesign(initial_sample_size,Dim);
fit = FUN(sam); 
for i=1:initial_sample_size
    NFE = NFE+1;
    Archive_FEs(NFE,:) = [NFE,fit(i)]; 
    Archive_convergence(1,i) = min(Archive_FEs(1:NFE,2));
end
hx = sam; hf = fit;                                             
[~,sidx] = sort(hf);                                         
hx = hx(sidx,:);  hf = hf(sidx);  
disp(['Iteration ' num2str(generation) ' Best Cost = ' num2str(min(hf)) ' NFE=' num2str(NFE)]);

for i = 1:10
    % 1. Build global surrogate model and initial sampling/offline optimization
    ghx = hx;  ghf=hf;  gs = length(hf);         
    ghxd = real(sqrt(ghx.^2*ones(size(ghx'))+ones(size(ghx))*(ghx').^2-2*ghx*(ghx')));
    spr = max(max(ghxd))/(Dim*gs)^(1/Dim);
    net = newrbe(ghx',ghf,spr);                       
    GlobalModelFUN = @(x) sim(net,x');
    MaxNFE = 1000*Dim;
    minerror = 1e-20;
    [candidate,~] = SLPSO(Dim, MaxNFE, GlobalModelFUN, minerror, ghx); % find a optimum of surrogate model by optimizer
    candidate_fitness = FUN(candidate); NFE = NFE + 1;
    Archive_FEs(NFE,:) = [NFE,candidate_fitness]; 
    Archive_convergence(1,NFE) = min(Archive_FEs(1:NFE,2));
    hx = [hx; candidate]; hf = [hf, candidate_fitness];
    generation = generation + 1;
    disp(['Iteration ' num2str(generation) ' Best Cost = ' num2str(min(hf)) ' NFE=' num2str(NFE)]);
end

% 2. ESPSO initialization
[~,sidx] = sort(hf);                                         
hx = hx(sidx,:); hf = hf(sidx); % history data
ps=Particle_Number;
VRmin = L_bound;
VRmax = U_bound;
cc=[2 2];   
if length(VRmin)==1
    VRmin=repmat(VRmin,1,Dim);
    VRmax=repmat(VRmax,1,Dim);
end
mv=0.5*(VRmax-VRmin);
VRmin=repmat(VRmin,ps,1);
VRmax=repmat(VRmax,ps,1);
Vmin=repmat(-mv,ps,1);
Vmax=-Vmin;
pos = hx(1:ps,:); 
e = hf(1:ps);
vel=Vmin+2.*Vmax.*rand(ps,Dim); 
pbest=pos;
pbestval=e; 
[gbestval,gbestid]=min(pbestval);
gbest=pbest(gbestid,:); 
gbestrep=repmat(gbest,ps,1);

while NFE < Max_NFE
        generation = generation + 1;
        
        % Build a population-based agent model
        [ghf,id] = sort(pbestval);                            
        gs = length(ghf(1:end));                        
        gs = min([gs, 300]);
        ghx = pbest(id(1:gs),:);  ghf=ghf(1:gs);           
        ghxd = real(sqrt(ghx.^2*ones(size(ghx'))+ones(size(ghx))*(ghx').^2-2*ghx*(ghx')));
        spr = max(max(ghxd))/(Dim*gs)^(1/Dim);
        net = newrbe(ghx',ghf,spr);                       
        GlobalModelFUN = @(x) sim(net,x');
        
        % S1. surrogate-Assisted Local Search
        MaxNFE = 200*Dim;
        minerror = 1e-20;
        [candidate,~] = DE(Dim, MaxNFE, GlobalModelFUN, minerror, pbest);
        [candidate] = full_crossover(GlobalModelFUN, [gbest; candidate]); 
        candidate_fitness = FUN(candidate); NFE = NFE + 1;
        hx = [hx; candidate]; hf = [hf, candidate_fitness];
        Archive_FEs(NFE,:) = [NFE,candidate_fitness];
        Archive_convergence(1,NFE) = min(Archive_FEs(1:NFE,2));
        [~, idx]= max(pbestval);  
        if candidate_fitness < pbestval(idx)
            [~, idx]= max(pbestval); 
            pbest(idx,:) = candidate;
            pbestval(idx) = candidate_fitness;
            pos(idx,:) = candidate;
            if show
                disp(['S1-Local search to replace the worst individual']);
            end
        end
        
        % PSO update to generate offspring
        aa=cc(1).*rand(ps,Dim).*(pbest-pos)+cc(2).*rand(ps,Dim).*(gbestrep-pos);
        iwt=0.9-NFE.*(0.5./Max_NFE);
        vel=iwt.*vel+aa;
        vel=(vel>Vmax).*Vmax+(vel<=Vmax).*vel;
        vel=(vel<Vmin).*Vmin+(vel>=Vmin).*vel;
        pos=pos+vel;
        pos=((pos>=VRmin)&(pos<=VRmax)).*pos...
            +(pos<VRmin).*(VRmin+0.25.*(VRmax-VRmin).*rand(ps,Dim))+(pos>VRmax).*(VRmax-0.25.*(VRmax-VRmin).*rand(ps,Dim));
        
        % predicted fitness value
        predicted_fitness = GlobalModelFUN(pos);
        
        % Calculate the distance criterion to avoid the surrogate model being too biased
        [~,id] = sort(pbestval);
        gs = floor(1/2*length(ghf(1:end)));
        ghx = pbest(id(1:gs),:);  ghf=ghf(1:gs);        
        center = mean(ghx);
        center_distance = pdist2(pos,  center)'; % Calculate the distance from all points to the seed point
        
        R_N = mapminmax(center_distance);
        E_N = mapminmax(predicted_fitness);
        
        loss = (R_N + E_N)/2;
        [~, idx] = min(loss);
        candidate = pos(idx,:);
        
        % PSO screening candidate point management
        if predicted_fitness > pbestval(idx) % For individuals screened out, the predicted fitness value is not as good as the historical optimal value of the individual.
            [newdata_x, newdata_f] = STR(FUN,pbest,pbestval); % S3.STR sampling new points to replace the last individual
            num_c = size(newdata_f,1);
            for a = 1:num_c
                NFE = NFE + 1; 
                candidate = newdata_x(a,:);
                candidate_fitness = newdata_f(a);
                hx = [hx; candidate]; hf = [hf, candidate_fitness];
                Archive_FEs(NFE,:) = [NFE,candidate_fitness];
                Archive_convergence(1,NFE) = min(Archive_FEs(1:NFE,2));
                [~, idx]= max(pbestval); % replace the worst
                if candidate_fitness < pbestval(idx)
                    pbest(idx,:) = candidate;
                    pbestval(idx) = candidate_fitness;
                    pos(idx,:) = candidate;
                    if show
                        disp(['S3-STR sampling new points to replace the last individual']);
                    end
                end
            end
        else
            candidate_fitness = FUN(candidate); NFE = NFE + 1;
            hx = [hx; candidate]; hf = [hf, candidate_fitness];
            Archive_FEs(NFE,:) = [NFE,candidate_fitness];
            Archive_convergence(1,NFE) = min(Archive_FEs(1:NFE,2));
            if candidate_fitness < pbestval(idx)     % S2.PSO screen candidate points and replace individual historical optimal ones
                pbest(idx,:) = candidate;
                pbestval(idx) = candidate_fitness;
                pos(idx,:) = candidate;
                if show
                    disp(['S2-PSO screen candidate points and replace individual historical optimal ones']);
                end
            else                          
                [~, idx]= max(pbestval); 
                if candidate_fitness < pbestval(idx)     % S4.PSO screen and replace the worst individual historical best
                    [~, idx]= max(pbestval); 
                    pbest(idx,:) = candidate;
                    pbestval(idx) = candidate_fitness;
                    pos(idx,:) = candidate;
                    if show
                        disp(['S4-PSO screen and replace the worst individual historical best']);
                    end
                else
                    [newdata_x, newdata_f] = STR(FUN,pbest,pbestval); % S5. STR sampling new points to replace the last individual
                    num_c = size(newdata_f,1);
                    for a = 1:num_c
                        NFE = NFE + 1; 
                        candidate = newdata_x(a,:);
                        candidate_fitness = newdata_f(a);
                        hx = [hx; candidate]; hf = [hf, candidate_fitness];
                        Archive_FEs(NFE,:) = [NFE,candidate_fitness];
                        Archive_convergence(1,NFE) = min(Archive_FEs(1:NFE,2));
                        [~, idx]= max(pbestval); % replace the worst
                        if candidate_fitness < pbestval(idx)
                            pbest(idx,:) = candidate;
                            pbestval(idx) = candidate_fitness;
                            pos(idx,:) = candidate;
                            if show
                                disp(['S5-STR sampling new points to replace the last individual']);
                            end
                        end
                    end
                end
            end
        end
        
        [gbestval,tmp]=min(pbestval);
        gbest=pbest(tmp,:);
        gbestrep=repmat(gbest,ps,1); % update the gbest
        
        % show
        disp(['Iteration ' num2str(generation) ' Best Cost = ' num2str(gbestval) ' NFE=' num2str(NFE)]);
    end
end