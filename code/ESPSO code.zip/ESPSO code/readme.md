# ESPSO Code

This code is part of the program that produces the results in the following paper:
Kuihua Huang, Huixiang Zhen, Wenyin Gong, Rui Wang and Weiwei Bian. "Surrogate-assisted evolutionary sampling particle swarm optimization for high-dimensional expensive optimization," in Neural Computing and Applications, 2023, https://doi.org/10.1007/s00521-023-08661-3.s