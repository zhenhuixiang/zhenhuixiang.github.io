function [y] = schwef(x)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [ps,D]=size(x);
	y2 = sum(x.*sin(sqrt(abs(x))),2);
    y = 418.9829*D - y2;
    y=y';
end