# MSEA

This repository establishes a model evaluation and selection based offline data-driven evolutionary algorithm different models are suitable for different problems. We concluded the relationship between models and problems. And evaluate and select suitable model for different offline data.

This code is part of the program that produces the results in the following paper:
Huixiang Zhen, Bing Xue, Wenyin Gong, Mengjie Zhang, Ling Wang. Offline evolutionary optimization with problem-driven model pool design and weighted model selection indicator, under review, 2025.
